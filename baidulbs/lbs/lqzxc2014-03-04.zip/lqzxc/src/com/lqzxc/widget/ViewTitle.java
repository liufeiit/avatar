package com.lqzxc.widget;

import com.lqzxc.R;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * �Զ���title
 * @author QQ472950043
 **/
public class ViewTitle extends RelativeLayout {

	TextView textView_title_back;
	TextView textView_title;
	TextView textView_title_right;
	LinearLayout btn_back;
	LinearLayout btn_right;

	public ViewTitle(Context context) {
		super(context);
	}
	/**
	 * �Զ���title
	 * @param mContext
	 * @param back ��߰�ť���֣�Ϊnull������
	 * @param title �������֣�Ϊ��
	 * @param right �ұ߰�ť���֣�Ϊnull������
	 * @author QQ472950043
	 **/
	public ViewTitle(Context mContext,String back,String title,String right) {
		super(mContext);
		// TODO Auto-generated constructor stub
		if (isInEditMode()) {
			return;
		}
		setWillNotDraw(false);
		LayoutInflater.from(mContext).inflate(R.layout.widget_title, this, true);

		textView_title_back = (TextView) findViewById(R.id.textview_widget_title_back);
		textView_title = (TextView) findViewById(R.id.textview_widget_title);
		textView_title_right = (TextView) findViewById(R.id.textview_widget_title_right);
		btn_back = (LinearLayout) findViewById(R.id.btn_widget_title_back);
		btn_right = (LinearLayout) findViewById(R.id.btn_widget_title_right);
		
		// ��ť����null������
		if(null==back)
			btn_back.setVisibility(View.GONE);
		else
			textView_title_back.setText(back);
		// ���ñ���
		textView_title.setText(title);
		// �Ұ�ť����null������
		if(null==right)
			btn_right.setVisibility(View.GONE);
		else
			textView_title_right.setText(right);
	}
	
	public void setOnBackListener(View.OnClickListener onBackListener) {
		btn_back.setOnClickListener(onBackListener);
	}

	public void setOnRightListener(View.OnClickListener onRightListener) {
		btn_right.setOnClickListener(onRightListener);
	}

}

	